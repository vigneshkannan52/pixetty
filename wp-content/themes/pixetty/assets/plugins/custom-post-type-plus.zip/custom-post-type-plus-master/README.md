# Custom Post Type Plus - WordPress Plugin

The Custom Post Type Plus plugin allows you to add new custom post types based on your needs and display them on your site using handy shortcodes.

If you are looking for helpful extensions to the block editor, download [Getwid WordPress blocks](https://motopress.com/products/getwid/), a free bundle of extra blocks and design patterns for Gutenberg.

## Support
This is a developer's portal for the Custom Post Type Plus and should not be used for support. Please visit the support page if you need to submit a support request.

## License
Custom Post Type Plus WordPress Plugin, Copyright (C) 2018, MotoPress.  
Custom Post Type Plus is distributed under the terms of the GNU GPL.

## Contributions
Anyone is welcome to contribute.

<p align="center">
    <br/>
    Made with 💙 by <a href="https://motopress.com/">MotoPress</a>.<br/>
</p>
